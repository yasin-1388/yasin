

const name = document.getElementById("name");
const lastname = document.getElementById("lastname");
const signIn = document.getElementById("signIn");
const output = document.getElementById("output");
const code = document.getElementById("code");
const fName = document.getElementById('f-Name')
const year = document.getElementById('year')
const month = document.getElementById('month')
const day = document.getElementById('day')
const nameList = []
let nameListText = ""
signIn.addEventListener("click", () => {
    const reg = {
        Name: name.value,
        LastName: lastname.value,
        Code: code.value,
        FName:fName.value,
        Year:year.value,
        Month:month.value,
        Day:day.value
        
    }
    nameList.push(reg);
    nameListText += "<li> esm: " + reg.Name + " famil: " + reg.LastName + " code: " + reg.Code + " esm pedar: " + reg.FName + "pld/years" + reg.Year + "old/month" + reg.Month + "old/day" + reg.Day + "</li>";
    output.innerHTML = nameListText

})